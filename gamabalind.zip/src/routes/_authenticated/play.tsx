import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/play")({
  head: () => ({ meta: [{ title: "Auction Room — BET MONEY" }, { name: "description", content: "Live fake-money auctions with your friends." }] }),
  component: PlayPage,
});

type Item = { id: string; name: string; emoji: string; description: string };
type Round = {
  id: string; host_id: string; status: string;
  choice_item_ids: string[]; item_id: string | null;
  current_bid: number; current_bidder_id: string | null; starting_bid: number;
  ends_at: string | null; winner_id: string | null; winning_bid: number | null; created_at: string;
};
type Bid = { id: string; round_id: string; bidder_id: string; amount: number; created_at: string };
type Profile = { id: string; username: string; balance: number };

function PlayPage() {
  const [userId, setUserId] = useState<string | null>(null);
  const [items, setItems] = useState<Record<string, Item>>({});
  const [profiles, setProfiles] = useState<Record<string, Profile>>({});
  const [rounds, setRounds] = useState<Round[]>([]);
  const [bids, setBids] = useState<Bid[]>([]);
  const [bidAmount, setBidAmount] = useState<Record<string, string>>({});
  const [now, setNow] = useState(Date.now());
  const settledRef = useRef<Set<string>>(new Set());

  useEffect(() => { supabase.auth.getUser().then(({ data }) => setUserId(data.user?.id ?? null)); }, []);
  useEffect(() => { const i = setInterval(() => setNow(Date.now()), 250); return () => clearInterval(i); }, []);

  useEffect(() => {
    (async () => {
      const [{ data: it }, { data: rs }, { data: ps }] = await Promise.all([
        supabase.from("items").select("*"),
        supabase.from("rounds").select("*").order("created_at", { ascending: false }).limit(15),
        supabase.from("profiles").select("id, username, balance"),
      ]);
      if (it) setItems(Object.fromEntries(it.map((x: Item) => [x.id, x])));
      if (rs) setRounds(rs as Round[]);
      if (ps) setProfiles(Object.fromEntries(ps.map((p: Profile) => [p.id, p])));
      const activeIds = (rs ?? []).filter((r: Round) => r.status === "bidding").map((r: Round) => r.id);
      if (activeIds.length) {
        const { data: bs } = await supabase.from("bids").select("*").in("round_id", activeIds).order("created_at", { ascending: false });
        if (bs) setBids(bs as Bid[]);
      }
    })();

    const ch = supabase
      .channel("play-room")
      .on("postgres_changes", { event: "*", schema: "public", table: "rounds" }, (payload) => {
        setRounds((prev) => {
          const row = payload.new as Round;
          if (payload.eventType === "DELETE") return prev.filter((r) => r.id !== (payload.old as Round).id);
          const exists = prev.some((r) => r.id === row.id);
          if (!exists) return [row, ...prev].slice(0, 15);
          return prev.map((r) => (r.id === row.id ? row : r));
        });
      })
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "bids" }, (payload) => {
        setBids((prev) => [payload.new as Bid, ...prev].slice(0, 200));
      })
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "profiles" }, (payload) => {
        const p = payload.new as Profile;
        setProfiles((prev) => ({ ...prev, [p.id]: p }));
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  // auto-settle expired rounds
  useEffect(() => {
    for (const r of rounds) {
      if (r.status === "bidding" && r.ends_at && new Date(r.ends_at).getTime() <= now && !settledRef.current.has(r.id)) {
        settledRef.current.add(r.id);
        supabase.rpc("settle_round", { _round_id: r.id }).then(({ error }) => {
          if (error) settledRef.current.delete(r.id);
        });
      }
    }
  }, [rounds, now]);

  const activeRounds = rounds.filter((r) => r.status !== "ended");
  const endedRounds = rounds.filter((r) => r.status === "ended").slice(0, 6);

  const startRound = async () => {
    if (!userId) return;
    const itemList = Object.values(items);
    if (itemList.length < 3) return;
    // pick 3 random items
    const shuffled = [...itemList].sort(() => Math.random() - 0.5).slice(0, 3);
    const { error } = await supabase.from("rounds").insert({
      host_id: userId,
      status: "choosing",
      choice_item_ids: shuffled.map((i) => i.id),
      starting_bid: 10,
    });
    if (error) toast.error(error.message);
  };

  const pickItem = async (roundId: string, itemId: string) => {
    const { error } = await supabase.rpc("pick_item", { _round_id: roundId, _item_id: itemId });
    if (error) toast.error(error.message);
  };

  const placeBid = async (roundId: string) => {
    const amt = parseInt(bidAmount[roundId] ?? "");
    if (!amt || amt <= 0) return toast.error("Enter a bid amount");
    const { error } = await supabase.rpc("place_bid", { _round_id: roundId, _amount: amt });
    if (error) toast.error(error.message);
    else setBidAmount((p) => ({ ...p, [roundId]: "" }));
  };

  const leaderboard = useMemo(
    () => Object.values(profiles).sort((a, b) => b.balance - a.balance).slice(0, 8),
    [profiles],
  );

  return (
    <AppShell>
      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <div className="space-y-6">
          <div className="panel p-6">
            <div className="flex items-center justify-between gap-4">
              <div>
                <h1 className="font-display text-3xl font-bold">Auction Room</h1>
                <p className="text-sm text-muted-foreground">Start a round, or bid on someone else's.</p>
              </div>
              <button onClick={startRound} className="btn-gold">🎩 Host a round</button>
            </div>
          </div>

          {activeRounds.length === 0 && (
            <div className="panel p-10 text-center">
              <div className="text-5xl">🪑</div>
              <p className="mt-3 text-muted-foreground">The auction table is quiet. Click <b>Host a round</b> to start one.</p>
            </div>
          )}

          {activeRounds.map((r) => (
            <RoundCard
              key={r.id}
              round={r}
              items={items}
              profiles={profiles}
              userId={userId}
              bids={bids.filter((b) => b.round_id === r.id)}
              now={now}
              bidValue={bidAmount[r.id] ?? ""}
              onBidValue={(v) => setBidAmount((p) => ({ ...p, [r.id]: v }))}
              onPick={(itemId) => pickItem(r.id, itemId)}
              onBid={() => placeBid(r.id)}
            />
          ))}

          {endedRounds.length > 0 && (
            <div className="panel p-6">
              <h2 className="font-display text-xl font-bold">Recent results</h2>
              <ul className="mt-3 divide-y divide-border/60">
                {endedRounds.map((r) => {
                  const item = r.item_id ? items[r.item_id] : null;
                  const winner = r.winner_id ? profiles[r.winner_id] : null;
                  return (
                    <li key={r.id} className="flex items-center justify-between py-3 text-sm">
                      <span className="flex items-center gap-2">
                        <span className="text-xl">{item?.emoji ?? "❓"}</span>
                        <span className="font-medium">{item?.name ?? "No item picked"}</span>
                      </span>
                      <span className="text-muted-foreground">
                        {winner ? <>won by <b>@{winner.username}</b> for {r.winning_bid} BM</> : "no bids"}
                      </span>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
        </div>

        <aside className="space-y-4">
          <div className="panel p-5">
            <h3 className="font-display text-lg font-bold">🏆 Richest players</h3>
            <ol className="mt-3 space-y-2">
              {leaderboard.map((p, i) => (
                <li key={p.id} className="flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2">
                    <span className="w-5 text-center text-muted-foreground">{i + 1}</span>
                    <span className="font-medium">@{p.username}{p.id === userId && <span className="ml-1 text-xs text-[color:var(--felt)]">(you)</span>}</span>
                  </span>
                  <span className="font-semibold">{p.balance}</span>
                </li>
              ))}
            </ol>
          </div>
          <div className="panel p-5 text-sm text-muted-foreground">
            <h3 className="font-display text-lg font-bold text-foreground">How it works</h3>
            <ul className="mt-2 space-y-1.5 list-disc pl-4">
              <li>Everyone gets <b>500 BET MONEY</b> at signup.</li>
              <li>Host a round → you get 3 items → pick one.</li>
              <li>Others bid live. Bids in the final 10s extend the clock.</li>
              <li>Winner pays and gets the item. Resell on the Market.</li>
            </ul>
          </div>
        </aside>
      </div>
    </AppShell>
  );
}

function RoundCard({
  round, items, profiles, userId, bids, now, bidValue, onBidValue, onPick, onBid,
}: {
  round: Round; items: Record<string, Item>; profiles: Record<string, Profile>;
  userId: string | null; bids: Bid[]; now: number;
  bidValue: string; onBidValue: (v: string) => void;
  onPick: (id: string) => void; onBid: () => void;
}) {
  const host = profiles[round.host_id];
  const isHost = userId === round.host_id;
  const item = round.item_id ? items[round.item_id] : null;
  const secLeft = round.ends_at ? Math.max(0, Math.ceil((new Date(round.ends_at).getTime() - now) / 1000)) : 0;
  const topBidder = round.current_bidder_id ? profiles[round.current_bidder_id] : null;
  const minBid = Math.max(round.starting_bid, round.current_bid + 1);

  return (
    <div className="panel overflow-hidden">
      <div className="flex items-center justify-between border-b border-border/60 bg-secondary/40 px-5 py-3">
        <span className="chip">🎩 Host @{host?.username ?? "…"}</span>
        {round.status === "bidding" && (
          <span className={`chip ${secLeft <= 5 ? "!bg-destructive !text-destructive-foreground !border-destructive" : ""}`}>
            ⏱ {secLeft}s
          </span>
        )}
        {round.status === "choosing" && <span className="chip">Picking item…</span>}
      </div>

      {round.status === "choosing" && (
        <div className="p-6">
          {isHost ? (
            <>
              <p className="mb-4 text-sm text-muted-foreground">Pick one — you can't bid on your own round.</p>
              <div className="grid gap-3 md:grid-cols-3">
                {round.choice_item_ids.map((id) => {
                  const it = items[id];
                  if (!it) return null;
                  return (
                    <button
                      key={id}
                      onClick={() => onPick(id)}
                      className="panel !rounded-xl p-4 text-left transition hover:-translate-y-1 hover:border-[color:var(--gold)]"
                    >
                      <div className="text-4xl">{it.emoji}</div>
                      <div className="mt-2 font-display text-lg font-bold">{it.name}</div>
                      <div className="mt-1 text-xs text-muted-foreground">{it.description}</div>
                    </button>
                  );
                })}
              </div>
            </>
          ) : (
            <p className="text-center text-muted-foreground">Waiting for @{host?.username} to pick an item…</p>
          )}
        </div>
      )}

      {round.status === "bidding" && item && (
        <div className="grid gap-5 p-6 md:grid-cols-[220px_1fr]">
          <div className="rounded-2xl bg-secondary p-6 text-center">
            <div className="text-7xl">{item.emoji}</div>
            <div className="mt-3 font-display text-lg font-bold">{item.name}</div>
            <div className="mt-1 text-xs text-muted-foreground">{item.description}</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Current bid</div>
            <div className="mt-1 flex items-baseline gap-3">
              <span className="font-display text-5xl font-black">{round.current_bid || 0}</span>
              <span className="text-lg font-semibold text-muted-foreground">BM</span>
            </div>
            <div className="mt-1 text-sm">
              {topBidder ? <>Leading: <b>@{topBidder.username}</b></> : <span className="text-muted-foreground">No bids yet. Opening at {round.starting_bid} BM.</span>}
            </div>

            {!isHost ? (
              <div className="mt-4 flex flex-wrap gap-2">
                <input
                  type="number" min={minBid} value={bidValue}
                  onChange={(e) => onBidValue(e.target.value)}
                  placeholder={`≥ ${minBid}`}
                  className="w-32 rounded-lg border border-input bg-card px-3 py-2 outline-none focus:border-[color:var(--gold)]"
                />
                <button onClick={onBid} className="btn-gold">Place bid</button>
                {[minBid, minBid + 10, minBid + 50].map((v) => (
                  <button key={v} onClick={() => { onBidValue(String(v)); }} className="btn-ghost">+{v - round.current_bid}</button>
                ))}
              </div>
            ) : (
              <p className="mt-4 text-sm text-muted-foreground italic">You're hosting — sit back and watch.</p>
            )}

            {bids.length > 0 && (
              <div className="mt-5 max-h-40 overflow-auto rounded-lg border border-border/60 bg-secondary/30 p-3 text-sm">
                {bids.slice(0, 10).map((b) => (
                  <div key={b.id} className="flex justify-between py-0.5">
                    <span>@{profiles[b.bidder_id]?.username ?? "…"}</span>
                    <span className="font-semibold">{b.amount} BM</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
