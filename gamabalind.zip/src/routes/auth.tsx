import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  validateSearch: z.object({ mode: z.enum(["signin", "signup"]).optional() }),
  head: () => ({ meta: [{ title: "Sign in — BET MONEY" }, { name: "description", content: "Sign in to play BET MONEY with your friends." }] }),
  component: AuthPage,
});

function AuthPage() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">(search.mode ?? "signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/play" });
    });
  }, [navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email, password,
          options: {
            emailRedirectTo: window.location.origin,
            data: { username: username.trim() || undefined },
          },
        });
        if (error) throw error;
        toast.success("Account created! You have 500 BET MONEY 🎉");
        navigate({ to: "/play" });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/play" });
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Something broke");
    } finally {
      setLoading(false);
    }
  };

  const google = async () => {
    setLoading(true);
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (result.error) {
      toast.error(result.error.message ?? "Google sign-in failed");
      setLoading(false);
      return;
    }
    if (result.redirected) return;
    navigate({ to: "/play" });
  };

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="panel w-full max-w-md p-8">
        <Link to="/" className="text-sm text-muted-foreground hover:underline">← back</Link>
        <div className="mt-2 text-3xl">🎲</div>
        <h1 className="mt-2 font-display text-3xl font-bold">
          {mode === "signup" ? "Join the table" : "Welcome back"}
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {mode === "signup" ? "New players start with 500 BET MONEY." : "Sign in to keep bidding."}
        </p>

        <button onClick={google} disabled={loading} className="btn-ghost mt-6 w-full">
          <span className="text-lg">🌐</span> Continue with Google
        </button>

        <div className="my-5 flex items-center gap-3 text-xs uppercase tracking-wide text-muted-foreground">
          <div className="h-px flex-1 bg-border" /> or email <div className="h-px flex-1 bg-border" />
        </div>

        <form onSubmit={submit} className="space-y-3">
          {mode === "signup" && (
            <div>
              <label className="text-xs font-semibold">Username</label>
              <input value={username} onChange={(e) => setUsername(e.target.value)}
                placeholder="LuckyDave" maxLength={24}
                className="mt-1 w-full rounded-lg border border-input bg-card px-3 py-2 outline-none focus:border-[color:var(--gold)]" />
            </div>
          )}
          <div>
            <label className="text-xs font-semibold">Email</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
              className="mt-1 w-full rounded-lg border border-input bg-card px-3 py-2 outline-none focus:border-[color:var(--gold)]" />
          </div>
          <div>
            <label className="text-xs font-semibold">Password</label>
            <input type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)}
              className="mt-1 w-full rounded-lg border border-input bg-card px-3 py-2 outline-none focus:border-[color:var(--gold)]" />
          </div>
          <button type="submit" disabled={loading} className="btn-gold w-full">
            {loading ? "…" : mode === "signup" ? "Create account & get 500 BET MONEY" : "Sign in"}
          </button>
        </form>

        <p className="mt-5 text-center text-sm text-muted-foreground">
          {mode === "signup" ? "Already have an account?" : "New here?"}{" "}
          <button
            onClick={() => setMode(mode === "signup" ? "signin" : "signup")}
            className="font-semibold text-[color:var(--felt)] hover:underline"
          >
            {mode === "signup" ? "Sign in" : "Create one"}
          </button>
        </p>
      </div>
    </div>
  );
}
